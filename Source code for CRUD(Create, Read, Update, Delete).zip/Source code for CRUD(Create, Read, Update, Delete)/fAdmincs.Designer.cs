﻿namespace hihi
{
    partial class fAdmincs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fAdmincs));
            tabControl1 = new TabControl();
            tabPRoom = new TabPage();
            titleDSP = new Label();
            titleQLPT = new Label();
            datagridviewPhong = new DataGridView();
            groupBox2 = new GroupBox();
            txtBfind_P = new TextBox();
            btnSearch_P = new Button();
            btnXoa_P = new Button();
            btnCapNhat_P = new Button();
            btnThem_P = new Button();
            groupBox1 = new GroupBox();
            label4 = new Label();
            panel4 = new Panel();
            numUDP_tinhtrang = new NumericUpDown();
            lblP_tinhtrang = new Label();
            panel3 = new Panel();
            txtBPprice = new TextBox();
            lblP_price = new Label();
            panel2 = new Panel();
            numUDP_SL = new NumericUpDown();
            lblP_quantity = new Label();
            panel1 = new Panel();
            txtBP_ID = new TextBox();
            lblP_ID = new Label();
            tabPCustomer = new TabPage();
            groupBox3 = new GroupBox();
            txtFind_KT = new TextBox();
            btnFind_KT = new Button();
            btnXoa_KT = new Button();
            btnCapNhat_KT = new Button();
            btnThem_KT = new Button();
            label5 = new Label();
            dataGridView2 = new DataGridView();
            groupBox4 = new GroupBox();
            panel5 = new Panel();
            txtBKTphone = new TextBox();
            lblKT_phone = new Label();
            panel6 = new Panel();
            rBtnKT_sex_0 = new RadioButton();
            rBtnKT_sex_1 = new RadioButton();
            lblKT_sex = new Label();
            panel7 = new Panel();
            rtxtBKTaddress = new RichTextBox();
            lblKT_address = new Label();
            panel8 = new Panel();
            txtKT_name = new TextBox();
            lblKT_name = new Label();
            panel9 = new Panel();
            txtBKTname = new TextBox();
            lblKT_CCCD = new Label();
            titleQLKT = new Label();
            tabPHopDong = new TabPage();
            groupBox6 = new GroupBox();
            txtBHD_find = new TextBox();
            btnFind_HD = new Button();
            btnCapnhat_HD = new Button();
            btnThem_HD = new Button();
            label6 = new Label();
            groupBox5 = new GroupBox();
            label7 = new Label();
            panel10 = new Panel();
            txtBHD_p_id = new TextBox();
            lblHD_p_id = new Label();
            panel11 = new Panel();
            txtBHD_cccd_ct = new TextBox();
            lblHD_cccd_ct = new Label();
            panel12 = new Panel();
            txtBHD_cccd_kt = new TextBox();
            lblHD_cccd_kt = new Label();
            panel13 = new Panel();
            dateTimePickerHD_dayend = new DateTimePicker();
            lblHD_dayend = new Label();
            panel15 = new Panel();
            dateTimePickerHD_daystart = new DateTimePicker();
            lblHD_daystart = new Label();
            panel14 = new Panel();
            numUDHD_tinhtrang = new NumericUpDown();
            lblHD_tinhtrang = new Label();
            panel16 = new Panel();
            txtBHD_ID = new TextBox();
            lnlHD_ID = new Label();
            dataGridView3 = new DataGridView();
            label15 = new Label();
            tabPage5 = new TabPage();
            label36 = new Label();
            dataGridView4 = new DataGridView();
            panel19 = new Panel();
            listView1 = new ListView();
            panel18 = new Panel();
            groupBox7 = new GroupBox();
            btnXoa_Hoadon = new Button();
            btnhoadon_find = new Button();
            btnCapnhap_hoadon = new Button();
            txtBHoaDon_find = new TextBox();
            btnThem_Hoadon = new Button();
            panel33 = new Panel();
            numericUpDownHoadon_tinhtrang = new NumericUpDown();
            lblHoaDon_tinhtrang = new Label();
            panel30 = new Panel();
            txtBHoadon_somoi = new TextBox();
            lblHoaDon_somoi = new Label();
            panel32 = new Panel();
            dateTimePickerHoaDon_date = new DateTimePicker();
            lblHoaDon_Ngay = new Label();
            panel31 = new Panel();
            txBHoadon_id = new TextBox();
            lblHoaDon_id = new Label();
            panel29 = new Panel();
            lblHoaDon_tongtien = new Label();
            txtBHoadon_tongtien = new TextBox();
            panel28 = new Panel();
            txtBHoadon_socu = new TextBox();
            lblHoaDon_socu = new Label();
            panel20 = new Panel();
            btnChoose = new Button();
            comboBoxServicesHoaDon_dv_id = new ComboBox();
            comboBoxRoomHoaDon_p_id = new ComboBox();
            label17 = new Label();
            tabPage1 = new TabPage();
            label18 = new Label();
            label19 = new Label();
            dataGridView5 = new DataGridView();
            groupBox9 = new GroupBox();
            txtBDv_find = new TextBox();
            btnDv_find = new Button();
            btnXoa_DV = new Button();
            btnCapnhat_DV = new Button();
            btnThem_DV = new Button();
            groupBox10 = new GroupBox();
            panel17 = new Panel();
            txtBDV_price = new TextBox();
            lnlDV_price = new Label();
            panel21 = new Panel();
            txtBDV_name = new TextBox();
            lblDV_name = new Label();
            panel22 = new Panel();
            txtBDV_id = new TextBox();
            lblDichvu_id = new Label();
            tabPage2 = new TabPage();
            dataGridView6 = new DataGridView();
            label26 = new Label();
            label27 = new Label();
            groupBox11 = new GroupBox();
            txtBfind_BSX = new TextBox();
            btnfind_BSX = new Button();
            btnXoa_BSX = new Button();
            btnCapNhat_BSX = new Button();
            btnThem_BSX = new Button();
            groupBox12 = new GroupBox();
            panel24 = new Panel();
            txtBBSX_id = new TextBox();
            lblBSX_id = new Label();
            panel25 = new Panel();
            txtBBSX_cccd_kt = new TextBox();
            lblBSX_cccd_kt = new Label();
            tabPage3 = new TabPage();
            label28 = new Label();
            label31 = new Label();
            dataGridView7 = new DataGridView();
            groupBox13 = new GroupBox();
            txtBfind_TKKT = new TextBox();
            btnfind_tkkt = new Button();
            btnXoa_tkkt = new Button();
            btnCapnhat_tkkt = new Button();
            btnThem_tkkkt = new Button();
            groupBox14 = new GroupBox();
            panel27 = new Panel();
            txtBTKKT_Matkhau = new TextBox();
            lblTKKT_Matkhau = new Label();
            panel23 = new Panel();
            txtBTKKKT_tenDN = new TextBox();
            lblTKKT_tenDN = new Label();
            panel26 = new Panel();
            txtBTKKT_cccd = new TextBox();
            lblTKKT_cccd = new Label();
            tabControl1.SuspendLayout();
            tabPRoom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)datagridviewPhong).BeginInit();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numUDP_tinhtrang).BeginInit();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numUDP_SL).BeginInit();
            panel1.SuspendLayout();
            tabPCustomer.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            groupBox4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            tabPHopDong.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox5.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            panel12.SuspendLayout();
            panel13.SuspendLayout();
            panel15.SuspendLayout();
            panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numUDHD_tinhtrang).BeginInit();
            panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            panel19.SuspendLayout();
            panel18.SuspendLayout();
            groupBox7.SuspendLayout();
            panel33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownHoadon_tinhtrang).BeginInit();
            panel30.SuspendLayout();
            panel32.SuspendLayout();
            panel31.SuspendLayout();
            panel29.SuspendLayout();
            panel28.SuspendLayout();
            panel20.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            groupBox9.SuspendLayout();
            groupBox10.SuspendLayout();
            panel17.SuspendLayout();
            panel21.SuspendLayout();
            panel22.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).BeginInit();
            groupBox11.SuspendLayout();
            groupBox12.SuspendLayout();
            panel24.SuspendLayout();
            panel25.SuspendLayout();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView7).BeginInit();
            groupBox13.SuspendLayout();
            groupBox14.SuspendLayout();
            panel27.SuspendLayout();
            panel23.SuspendLayout();
            panel26.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPRoom);
            tabControl1.Controls.Add(tabPCustomer);
            tabControl1.Controls.Add(tabPHopDong);
            tabControl1.Controls.Add(tabPage5);
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(-1, 1);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1042, 533);
            tabControl1.TabIndex = 0;
            // 
            // tabPRoom
            // 
            tabPRoom.Controls.Add(titleDSP);
            tabPRoom.Controls.Add(titleQLPT);
            tabPRoom.Controls.Add(datagridviewPhong);
            tabPRoom.Controls.Add(groupBox2);
            tabPRoom.Controls.Add(groupBox1);
            tabPRoom.Location = new Point(4, 29);
            tabPRoom.Name = "tabPRoom";
            tabPRoom.Padding = new Padding(3);
            tabPRoom.Size = new Size(1034, 500);
            tabPRoom.TabIndex = 1;
            tabPRoom.Text = "Phòng trọ";
            tabPRoom.UseVisualStyleBackColor = true;
            // 
            // titleDSP
            // 
            titleDSP.AutoSize = true;
            titleDSP.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            titleDSP.ForeColor = Color.DodgerBlue;
            titleDSP.Location = new Point(32, 270);
            titleDSP.Name = "titleDSP";
            titleDSP.Size = new Size(153, 23);
            titleDSP.TabIndex = 10;
            titleDSP.Text = "Danh sách phòng:";
            // 
            // titleQLPT
            // 
            titleQLPT.AutoSize = true;
            titleQLPT.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            titleQLPT.ForeColor = Color.DodgerBlue;
            titleQLPT.Location = new Point(413, 30);
            titleQLPT.Name = "titleQLPT";
            titleQLPT.Size = new Size(244, 30);
            titleQLPT.TabIndex = 9;
            titleQLPT.Text = "QUẢN LÝ PHÒNG TRỌ";
            // 
            // datagridviewPhong
            // 
            datagridviewPhong.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            datagridviewPhong.Location = new Point(32, 296);
            datagridviewPhong.Name = "datagridviewPhong";
            datagridviewPhong.RowHeadersWidth = 51;
            datagridviewPhong.Size = new Size(974, 187);
            datagridviewPhong.TabIndex = 8;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtBfind_P);
            groupBox2.Controls.Add(btnSearch_P);
            groupBox2.Controls.Add(btnXoa_P);
            groupBox2.Controls.Add(btnCapNhat_P);
            groupBox2.Controls.Add(btnThem_P);
            groupBox2.Location = new Point(762, 75);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(244, 192);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Chức năng";
            // 
            // txtBfind_P
            // 
            txtBfind_P.BorderStyle = BorderStyle.FixedSingle;
            txtBfind_P.Location = new Point(16, 29);
            txtBfind_P.Name = "txtBfind_P";
            txtBfind_P.PlaceholderText = "   Tìm kiếm";
            txtBfind_P.Size = new Size(191, 27);
            txtBfind_P.TabIndex = 2;
            // 
            // btnSearch_P
            // 
            btnSearch_P.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnSearch_P.BackgroundImageLayout = ImageLayout.Stretch;
            btnSearch_P.Location = new Point(208, 26);
            btnSearch_P.Name = "btnSearch_P";
            btnSearch_P.Size = new Size(30, 30);
            btnSearch_P.TabIndex = 3;
            btnSearch_P.UseVisualStyleBackColor = true;
            // 
            // btnXoa_P
            // 
            btnXoa_P.Location = new Point(16, 153);
            btnXoa_P.Name = "btnXoa_P";
            btnXoa_P.Size = new Size(127, 33);
            btnXoa_P.TabIndex = 2;
            btnXoa_P.Text = "Xoá";
            btnXoa_P.UseVisualStyleBackColor = true;
            // 
            // btnCapNhat_P
            // 
            btnCapNhat_P.Location = new Point(16, 111);
            btnCapNhat_P.Name = "btnCapNhat_P";
            btnCapNhat_P.Size = new Size(127, 36);
            btnCapNhat_P.TabIndex = 1;
            btnCapNhat_P.Text = "Cập nhật";
            btnCapNhat_P.UseVisualStyleBackColor = true;
            // 
            // btnThem_P
            // 
            btnThem_P.Location = new Point(16, 68);
            btnThem_P.Name = "btnThem_P";
            btnThem_P.Size = new Size(127, 37);
            btnThem_P.TabIndex = 0;
            btnThem_P.Text = "Thêm";
            btnThem_P.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(panel4);
            groupBox1.Controls.Add(panel3);
            groupBox1.Controls.Add(panel2);
            groupBox1.Controls.Add(panel1);
            groupBox1.Location = new Point(32, 75);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(724, 192);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin phòng trọ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 7.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(357, 137);
            label4.Name = "label4";
            label4.Size = new Size(134, 17);
            label4.TabIndex = 6;
            label4.Text = "0: Trống; 1: Đang thuê";
            // 
            // panel4
            // 
            panel4.Controls.Add(numUDP_tinhtrang);
            panel4.Controls.Add(lblP_tinhtrang);
            panel4.Location = new Point(345, 94);
            panel4.Name = "panel4";
            panel4.Size = new Size(349, 34);
            panel4.TabIndex = 3;
            // 
            // numUDP_tinhtrang
            // 
            numUDP_tinhtrang.Location = new Point(142, 3);
            numUDP_tinhtrang.Name = "numUDP_tinhtrang";
            numUDP_tinhtrang.Size = new Size(77, 27);
            numUDP_tinhtrang.TabIndex = 4;
            // 
            // lblP_tinhtrang
            // 
            lblP_tinhtrang.AutoSize = true;
            lblP_tinhtrang.Location = new Point(12, 6);
            lblP_tinhtrang.Name = "lblP_tinhtrang";
            lblP_tinhtrang.Size = new Size(79, 20);
            lblP_tinhtrang.TabIndex = 0;
            lblP_tinhtrang.Text = "Tình trạng:";
            // 
            // panel3
            // 
            panel3.Controls.Add(txtBPprice);
            panel3.Controls.Add(lblP_price);
            panel3.Location = new Point(345, 30);
            panel3.Name = "panel3";
            panel3.Size = new Size(349, 34);
            panel3.TabIndex = 3;
            // 
            // txtBPprice
            // 
            txtBPprice.BorderStyle = BorderStyle.FixedSingle;
            txtBPprice.Location = new Point(142, 3);
            txtBPprice.Name = "txtBPprice";
            txtBPprice.Size = new Size(129, 27);
            txtBPprice.TabIndex = 3;
            // 
            // lblP_price
            // 
            lblP_price.AutoSize = true;
            lblP_price.Location = new Point(12, 6);
            lblP_price.Name = "lblP_price";
            lblP_price.Size = new Size(81, 20);
            lblP_price.TabIndex = 0;
            lblP_price.Text = "Giá phòng:";
            // 
            // panel2
            // 
            panel2.Controls.Add(numUDP_SL);
            panel2.Controls.Add(lblP_quantity);
            panel2.Location = new Point(15, 94);
            panel2.Name = "panel2";
            panel2.Size = new Size(283, 34);
            panel2.TabIndex = 2;
            // 
            // numUDP_SL
            // 
            numUDP_SL.Location = new Point(142, 4);
            numUDP_SL.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            numUDP_SL.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numUDP_SL.Name = "numUDP_SL";
            numUDP_SL.Size = new Size(75, 27);
            numUDP_SL.TabIndex = 2;
            numUDP_SL.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblP_quantity
            // 
            lblP_quantity.AutoSize = true;
            lblP_quantity.Location = new Point(12, 6);
            lblP_quantity.Name = "lblP_quantity";
            lblP_quantity.Size = new Size(72, 20);
            lblP_quantity.TabIndex = 0;
            lblP_quantity.Text = "Số lượng:";
            // 
            // panel1
            // 
            panel1.Controls.Add(txtBP_ID);
            panel1.Controls.Add(lblP_ID);
            panel1.Location = new Point(15, 30);
            panel1.Name = "panel1";
            panel1.Size = new Size(283, 34);
            panel1.TabIndex = 0;
            // 
            // txtBP_ID
            // 
            txtBP_ID.BorderStyle = BorderStyle.FixedSingle;
            txtBP_ID.Location = new Point(142, 3);
            txtBP_ID.Name = "txtBP_ID";
            txtBP_ID.Size = new Size(129, 27);
            txtBP_ID.TabIndex = 1;
            // 
            // lblP_ID
            // 
            lblP_ID.AutoSize = true;
            lblP_ID.Location = new Point(12, 6);
            lblP_ID.Name = "lblP_ID";
            lblP_ID.Size = new Size(103, 20);
            lblP_ID.TabIndex = 0;
            lblP_ID.Text = "Mã phòng trọ:";
            // 
            // tabPCustomer
            // 
            tabPCustomer.Controls.Add(groupBox3);
            tabPCustomer.Controls.Add(label5);
            tabPCustomer.Controls.Add(dataGridView2);
            tabPCustomer.Controls.Add(groupBox4);
            tabPCustomer.Controls.Add(titleQLKT);
            tabPCustomer.Location = new Point(4, 29);
            tabPCustomer.Name = "tabPCustomer";
            tabPCustomer.Padding = new Padding(3);
            tabPCustomer.Size = new Size(1034, 500);
            tabPCustomer.TabIndex = 2;
            tabPCustomer.Text = "Khách thuê";
            tabPCustomer.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(txtFind_KT);
            groupBox3.Controls.Add(btnFind_KT);
            groupBox3.Controls.Add(btnXoa_KT);
            groupBox3.Controls.Add(btnCapNhat_KT);
            groupBox3.Controls.Add(btnThem_KT);
            groupBox3.Location = new Point(758, 44);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(244, 207);
            groupBox3.TabIndex = 17;
            groupBox3.TabStop = false;
            groupBox3.Text = "Chức năng";
            // 
            // txtFind_KT
            // 
            txtFind_KT.BorderStyle = BorderStyle.FixedSingle;
            txtFind_KT.Location = new Point(16, 29);
            txtFind_KT.Name = "txtFind_KT";
            txtFind_KT.PlaceholderText = "   Tìm kiếm";
            txtFind_KT.Size = new Size(191, 27);
            txtFind_KT.TabIndex = 2;
            // 
            // btnFind_KT
            // 
            btnFind_KT.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnFind_KT.BackgroundImageLayout = ImageLayout.Stretch;
            btnFind_KT.Location = new Point(208, 26);
            btnFind_KT.Name = "btnFind_KT";
            btnFind_KT.Size = new Size(30, 30);
            btnFind_KT.TabIndex = 3;
            btnFind_KT.UseVisualStyleBackColor = true;
            // 
            // btnXoa_KT
            // 
            btnXoa_KT.Location = new Point(16, 157);
            btnXoa_KT.Name = "btnXoa_KT";
            btnXoa_KT.Size = new Size(127, 33);
            btnXoa_KT.TabIndex = 2;
            btnXoa_KT.Text = "Xoá";
            btnXoa_KT.UseVisualStyleBackColor = true;
            // 
            // btnCapNhat_KT
            // 
            btnCapNhat_KT.Location = new Point(16, 115);
            btnCapNhat_KT.Name = "btnCapNhat_KT";
            btnCapNhat_KT.Size = new Size(127, 36);
            btnCapNhat_KT.TabIndex = 1;
            btnCapNhat_KT.Text = "Cập nhật";
            btnCapNhat_KT.UseVisualStyleBackColor = true;
            // 
            // btnThem_KT
            // 
            btnThem_KT.Location = new Point(16, 68);
            btnThem_KT.Name = "btnThem_KT";
            btnThem_KT.Size = new Size(127, 37);
            btnThem_KT.TabIndex = 0;
            btnThem_KT.Text = "Thêm";
            btnThem_KT.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.ForeColor = Color.DodgerBlue;
            label5.Location = new Point(26, 265);
            label5.Name = "label5";
            label5.Size = new Size(189, 23);
            label5.TabIndex = 16;
            label5.Text = "Danh sách khách thuê:";
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(26, 291);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(976, 199);
            dataGridView2.TabIndex = 14;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(panel5);
            groupBox4.Controls.Add(panel6);
            groupBox4.Controls.Add(panel7);
            groupBox4.Controls.Add(panel8);
            groupBox4.Controls.Add(panel9);
            groupBox4.Location = new Point(26, 44);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(711, 207);
            groupBox4.TabIndex = 12;
            groupBox4.TabStop = false;
            groupBox4.Text = "Thông tin khách thuê";
            // 
            // panel5
            // 
            panel5.Controls.Add(txtBKTphone);
            panel5.Controls.Add(lblKT_phone);
            panel5.Location = new Point(15, 151);
            panel5.Name = "panel5";
            panel5.Size = new Size(324, 34);
            panel5.TabIndex = 3;
            // 
            // txtBKTphone
            // 
            txtBKTphone.BorderStyle = BorderStyle.FixedSingle;
            txtBKTphone.Location = new Point(94, 4);
            txtBKTphone.Name = "txtBKTphone";
            txtBKTphone.Size = new Size(182, 27);
            txtBKTphone.TabIndex = 3;
            // 
            // lblKT_phone
            // 
            lblKT_phone.AutoSize = true;
            lblKT_phone.Location = new Point(12, 6);
            lblKT_phone.Name = "lblKT_phone";
            lblKT_phone.Size = new Size(39, 20);
            lblKT_phone.TabIndex = 0;
            lblKT_phone.Text = "SĐT:";
            // 
            // panel6
            // 
            panel6.Controls.Add(rBtnKT_sex_0);
            panel6.Controls.Add(rBtnKT_sex_1);
            panel6.Controls.Add(lblKT_sex);
            panel6.Location = new Point(356, 30);
            panel6.Name = "panel6";
            panel6.Size = new Size(349, 34);
            panel6.TabIndex = 3;
            // 
            // rBtnKT_sex_0
            // 
            rBtnKT_sex_0.AutoSize = true;
            rBtnKT_sex_0.Location = new Point(97, 5);
            rBtnKT_sex_0.Name = "rBtnKT_sex_0";
            rBtnKT_sex_0.Size = new Size(62, 24);
            rBtnKT_sex_0.TabIndex = 4;
            rBtnKT_sex_0.TabStop = true;
            rBtnKT_sex_0.Text = "Nam";
            rBtnKT_sex_0.UseVisualStyleBackColor = true;
            // 
            // rBtnKT_sex_1
            // 
            rBtnKT_sex_1.AutoSize = true;
            rBtnKT_sex_1.Location = new Point(177, 4);
            rBtnKT_sex_1.Name = "rBtnKT_sex_1";
            rBtnKT_sex_1.Size = new Size(50, 24);
            rBtnKT_sex_1.TabIndex = 5;
            rBtnKT_sex_1.TabStop = true;
            rBtnKT_sex_1.Text = "Nữ";
            rBtnKT_sex_1.UseVisualStyleBackColor = true;
            // 
            // lblKT_sex
            // 
            lblKT_sex.AutoSize = true;
            lblKT_sex.Location = new Point(12, 6);
            lblKT_sex.Name = "lblKT_sex";
            lblKT_sex.Size = new Size(68, 20);
            lblKT_sex.TabIndex = 0;
            lblKT_sex.Text = "Giới tính:";
            // 
            // panel7
            // 
            panel7.Controls.Add(rtxtBKTaddress);
            panel7.Controls.Add(lblKT_address);
            panel7.Location = new Point(356, 93);
            panel7.Name = "panel7";
            panel7.Size = new Size(349, 92);
            panel7.TabIndex = 3;
            // 
            // rtxtBKTaddress
            // 
            rtxtBKTaddress.BorderStyle = BorderStyle.FixedSingle;
            rtxtBKTaddress.Location = new Point(97, 7);
            rtxtBKTaddress.Name = "rtxtBKTaddress";
            rtxtBKTaddress.Size = new Size(235, 66);
            rtxtBKTaddress.TabIndex = 6;
            rtxtBKTaddress.Text = "";
            // 
            // lblKT_address
            // 
            lblKT_address.AutoSize = true;
            lblKT_address.Location = new Point(12, 6);
            lblKT_address.Name = "lblKT_address";
            lblKT_address.Size = new Size(67, 20);
            lblKT_address.TabIndex = 0;
            lblKT_address.Text = "Hộ khẩu:";
            // 
            // panel8
            // 
            panel8.Controls.Add(txtKT_name);
            panel8.Controls.Add(lblKT_name);
            panel8.Location = new Point(15, 94);
            panel8.Name = "panel8";
            panel8.Size = new Size(324, 34);
            panel8.TabIndex = 2;
            // 
            // txtKT_name
            // 
            txtKT_name.BorderStyle = BorderStyle.FixedSingle;
            txtKT_name.Location = new Point(94, 4);
            txtKT_name.Name = "txtKT_name";
            txtKT_name.Size = new Size(227, 27);
            txtKT_name.TabIndex = 2;
            // 
            // lblKT_name
            // 
            lblKT_name.AutoSize = true;
            lblKT_name.Location = new Point(12, 6);
            lblKT_name.Name = "lblKT_name";
            lblKT_name.Size = new Size(76, 20);
            lblKT_name.TabIndex = 0;
            lblKT_name.Text = "Họ và tên:";
            // 
            // panel9
            // 
            panel9.Controls.Add(txtBKTname);
            panel9.Controls.Add(lblKT_CCCD);
            panel9.Location = new Point(15, 30);
            panel9.Name = "panel9";
            panel9.Size = new Size(324, 34);
            panel9.TabIndex = 0;
            // 
            // txtBKTname
            // 
            txtBKTname.BorderStyle = BorderStyle.FixedSingle;
            txtBKTname.Location = new Point(94, 3);
            txtBKTname.Name = "txtBKTname";
            txtBKTname.Size = new Size(227, 27);
            txtBKTname.TabIndex = 1;
            // 
            // lblKT_CCCD
            // 
            lblKT_CCCD.AutoSize = true;
            lblKT_CCCD.Location = new Point(12, 6);
            lblKT_CCCD.Name = "lblKT_CCCD";
            lblKT_CCCD.Size = new Size(71, 20);
            lblKT_CCCD.TabIndex = 0;
            lblKT_CCCD.Text = "Số CCCD:";
            // 
            // titleQLKT
            // 
            titleQLKT.AutoSize = true;
            titleQLKT.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            titleQLKT.ForeColor = Color.DodgerBlue;
            titleQLKT.Location = new Point(409, 11);
            titleQLKT.Name = "titleQLKT";
            titleQLKT.Size = new Size(254, 30);
            titleQLKT.TabIndex = 15;
            titleQLKT.Text = "QUẢN LÝ KHÁCH THUÊ";
            // 
            // tabPHopDong
            // 
            tabPHopDong.Controls.Add(groupBox6);
            tabPHopDong.Controls.Add(label6);
            tabPHopDong.Controls.Add(groupBox5);
            tabPHopDong.Controls.Add(dataGridView3);
            tabPHopDong.Controls.Add(label15);
            tabPHopDong.Location = new Point(4, 29);
            tabPHopDong.Name = "tabPHopDong";
            tabPHopDong.Padding = new Padding(3);
            tabPHopDong.Size = new Size(1034, 500);
            tabPHopDong.TabIndex = 3;
            tabPHopDong.Text = "Hợp đồng";
            tabPHopDong.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(txtBHD_find);
            groupBox6.Controls.Add(btnFind_HD);
            groupBox6.Controls.Add(btnCapnhat_HD);
            groupBox6.Controls.Add(btnThem_HD);
            groupBox6.Location = new Point(757, 41);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(244, 169);
            groupBox6.TabIndex = 23;
            groupBox6.TabStop = false;
            groupBox6.Text = "Chức năng";
            // 
            // txtBHD_find
            // 
            txtBHD_find.BorderStyle = BorderStyle.FixedSingle;
            txtBHD_find.Location = new Point(16, 29);
            txtBHD_find.Name = "txtBHD_find";
            txtBHD_find.PlaceholderText = "   Tìm kiếm";
            txtBHD_find.Size = new Size(191, 27);
            txtBHD_find.TabIndex = 2;
            // 
            // btnFind_HD
            // 
            btnFind_HD.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnFind_HD.BackgroundImageLayout = ImageLayout.Stretch;
            btnFind_HD.Location = new Point(208, 26);
            btnFind_HD.Name = "btnFind_HD";
            btnFind_HD.Size = new Size(30, 30);
            btnFind_HD.TabIndex = 3;
            btnFind_HD.UseVisualStyleBackColor = true;
            // 
            // btnCapnhat_HD
            // 
            btnCapnhat_HD.Location = new Point(16, 111);
            btnCapnhat_HD.Name = "btnCapnhat_HD";
            btnCapnhat_HD.Size = new Size(127, 36);
            btnCapnhat_HD.TabIndex = 1;
            btnCapnhat_HD.Text = "Cập nhật";
            btnCapnhat_HD.UseVisualStyleBackColor = true;
            // 
            // btnThem_HD
            // 
            btnThem_HD.Location = new Point(16, 68);
            btnThem_HD.Name = "btnThem_HD";
            btnThem_HD.Size = new Size(127, 37);
            btnThem_HD.TabIndex = 0;
            btnThem_HD.Text = "Thêm";
            btnThem_HD.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label6.ForeColor = Color.DodgerBlue;
            label6.Location = new Point(382, 13);
            label6.Name = "label6";
            label6.Size = new Size(233, 30);
            label6.TabIndex = 21;
            label6.Text = "QUẢN LÝ HỢP ĐỒNG";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(label7);
            groupBox5.Controls.Add(panel10);
            groupBox5.Controls.Add(panel11);
            groupBox5.Controls.Add(panel12);
            groupBox5.Controls.Add(panel13);
            groupBox5.Controls.Add(panel15);
            groupBox5.Controls.Add(panel14);
            groupBox5.Controls.Add(panel16);
            groupBox5.Location = new Point(34, 41);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(711, 207);
            groupBox5.TabIndex = 18;
            groupBox5.TabStop = false;
            groupBox5.Text = "Thông tin khách thuê";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 7.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlDarkDark;
            label7.Location = new Point(442, 152);
            label7.Name = "label7";
            label7.Size = new Size(244, 17);
            label7.TabIndex = 5;
            label7.Text = "0: Kết thúc; 1: Còn hạn; 2: Gia hạn; 3: Huỷ";
            // 
            // panel10
            // 
            panel10.Controls.Add(txtBHD_p_id);
            panel10.Controls.Add(lblHD_p_id);
            panel10.Location = new Point(15, 157);
            panel10.Name = "panel10";
            panel10.Size = new Size(387, 34);
            panel10.TabIndex = 4;
            // 
            // txtBHD_p_id
            // 
            txtBHD_p_id.BorderStyle = BorderStyle.FixedSingle;
            txtBHD_p_id.Location = new Point(179, 3);
            txtBHD_p_id.Name = "txtBHD_p_id";
            txtBHD_p_id.Size = new Size(108, 27);
            txtBHD_p_id.TabIndex = 1;
            // 
            // lblHD_p_id
            // 
            lblHD_p_id.AutoSize = true;
            lblHD_p_id.Location = new Point(12, 6);
            lblHD_p_id.Name = "lblHD_p_id";
            lblHD_p_id.Size = new Size(80, 20);
            lblHD_p_id.TabIndex = 0;
            lblHD_p_id.Text = "Mã phòng:";
            // 
            // panel11
            // 
            panel11.Controls.Add(txtBHD_cccd_ct);
            panel11.Controls.Add(lblHD_cccd_ct);
            panel11.Location = new Point(15, 114);
            panel11.Name = "panel11";
            panel11.Size = new Size(387, 34);
            panel11.TabIndex = 3;
            // 
            // txtBHD_cccd_ct
            // 
            txtBHD_cccd_ct.BorderStyle = BorderStyle.FixedSingle;
            txtBHD_cccd_ct.Location = new Point(179, 3);
            txtBHD_cccd_ct.Name = "txtBHD_cccd_ct";
            txtBHD_cccd_ct.Size = new Size(205, 27);
            txtBHD_cccd_ct.TabIndex = 1;
            // 
            // lblHD_cccd_ct
            // 
            lblHD_cccd_ct.AutoSize = true;
            lblHD_cccd_ct.Location = new Point(12, 6);
            lblHD_cccd_ct.Name = "lblHD_cccd_ct";
            lblHD_cccd_ct.Size = new Size(161, 20);
            lblHD_cccd_ct.TabIndex = 0;
            lblHD_cccd_ct.Text = "Số CCCD bên cho thuê:";
            // 
            // panel12
            // 
            panel12.Controls.Add(txtBHD_cccd_kt);
            panel12.Controls.Add(lblHD_cccd_kt);
            panel12.Location = new Point(15, 74);
            panel12.Name = "panel12";
            panel12.Size = new Size(387, 34);
            panel12.TabIndex = 2;
            // 
            // txtBHD_cccd_kt
            // 
            txtBHD_cccd_kt.BorderStyle = BorderStyle.FixedSingle;
            txtBHD_cccd_kt.Location = new Point(179, 3);
            txtBHD_cccd_kt.Name = "txtBHD_cccd_kt";
            txtBHD_cccd_kt.Size = new Size(205, 27);
            txtBHD_cccd_kt.TabIndex = 1;
            // 
            // lblHD_cccd_kt
            // 
            lblHD_cccd_kt.AutoSize = true;
            lblHD_cccd_kt.Location = new Point(12, 6);
            lblHD_cccd_kt.Name = "lblHD_cccd_kt";
            lblHD_cccd_kt.Size = new Size(133, 20);
            lblHD_cccd_kt.TabIndex = 0;
            lblHD_cccd_kt.Text = "Số CCCD bên thuê:";
            // 
            // panel13
            // 
            panel13.Controls.Add(dateTimePickerHD_dayend);
            panel13.Controls.Add(lblHD_dayend);
            panel13.Location = new Point(430, 74);
            panel13.Name = "panel13";
            panel13.Size = new Size(256, 34);
            panel13.TabIndex = 3;
            // 
            // dateTimePickerHD_dayend
            // 
            dateTimePickerHD_dayend.Location = new Point(119, 4);
            dateTimePickerHD_dayend.Name = "dateTimePickerHD_dayend";
            dateTimePickerHD_dayend.Size = new Size(125, 27);
            dateTimePickerHD_dayend.TabIndex = 1;
            dateTimePickerHD_dayend.Value = new DateTime(2024, 11, 26, 0, 0, 0, 0);
            // 
            // lblHD_dayend
            // 
            lblHD_dayend.AutoSize = true;
            lblHD_dayend.Location = new Point(12, 6);
            lblHD_dayend.Name = "lblHD_dayend";
            lblHD_dayend.Size = new Size(103, 20);
            lblHD_dayend.TabIndex = 0;
            lblHD_dayend.Text = "Ngày kết thúc:";
            // 
            // panel15
            // 
            panel15.Controls.Add(dateTimePickerHD_daystart);
            panel15.Controls.Add(lblHD_daystart);
            panel15.Location = new Point(430, 30);
            panel15.Name = "panel15";
            panel15.Size = new Size(256, 34);
            panel15.TabIndex = 2;
            // 
            // dateTimePickerHD_daystart
            // 
            dateTimePickerHD_daystart.Location = new Point(120, 4);
            dateTimePickerHD_daystart.Name = "dateTimePickerHD_daystart";
            dateTimePickerHD_daystart.Size = new Size(125, 27);
            dateTimePickerHD_daystart.TabIndex = 2;
            dateTimePickerHD_daystart.Value = new DateTime(2024, 11, 26, 0, 0, 0, 0);
            // 
            // lblHD_daystart
            // 
            lblHD_daystart.AutoSize = true;
            lblHD_daystart.Location = new Point(12, 6);
            lblHD_daystart.Name = "lblHD_daystart";
            lblHD_daystart.Size = new Size(102, 20);
            lblHD_daystart.TabIndex = 0;
            lblHD_daystart.Text = "Ngày bắt đầu:";
            // 
            // panel14
            // 
            panel14.Controls.Add(numUDHD_tinhtrang);
            panel14.Controls.Add(lblHD_tinhtrang);
            panel14.Location = new Point(430, 115);
            panel14.Name = "panel14";
            panel14.Size = new Size(256, 34);
            panel14.TabIndex = 3;
            // 
            // numUDHD_tinhtrang
            // 
            numUDHD_tinhtrang.Location = new Point(119, 4);
            numUDHD_tinhtrang.Maximum = new decimal(new int[] { 3, 0, 0, 0 });
            numUDHD_tinhtrang.Name = "numUDHD_tinhtrang";
            numUDHD_tinhtrang.Size = new Size(80, 27);
            numUDHD_tinhtrang.TabIndex = 1;
            // 
            // lblHD_tinhtrang
            // 
            lblHD_tinhtrang.AutoSize = true;
            lblHD_tinhtrang.Location = new Point(12, 6);
            lblHD_tinhtrang.Name = "lblHD_tinhtrang";
            lblHD_tinhtrang.Size = new Size(79, 20);
            lblHD_tinhtrang.TabIndex = 0;
            lblHD_tinhtrang.Text = "Tình trạng:";
            // 
            // panel16
            // 
            panel16.Controls.Add(txtBHD_ID);
            panel16.Controls.Add(lnlHD_ID);
            panel16.Location = new Point(15, 30);
            panel16.Name = "panel16";
            panel16.Size = new Size(387, 34);
            panel16.TabIndex = 0;
            // 
            // txtBHD_ID
            // 
            txtBHD_ID.BorderStyle = BorderStyle.FixedSingle;
            txtBHD_ID.Location = new Point(179, 3);
            txtBHD_ID.Name = "txtBHD_ID";
            txtBHD_ID.Size = new Size(115, 27);
            txtBHD_ID.TabIndex = 1;
            // 
            // lnlHD_ID
            // 
            lnlHD_ID.AutoSize = true;
            lnlHD_ID.Location = new Point(12, 6);
            lnlHD_ID.Name = "lnlHD_ID";
            lnlHD_ID.Size = new Size(102, 20);
            lnlHD_ID.TabIndex = 0;
            lnlHD_ID.Text = "Mã hợp đồng:";
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(34, 277);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(967, 208);
            dataGridView3.TabIndex = 20;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label15.ForeColor = Color.DodgerBlue;
            label15.Location = new Point(34, 250);
            label15.Name = "label15";
            label15.Size = new Size(180, 23);
            label15.TabIndex = 22;
            label15.Text = "Danh sách hợp đồng:";
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(label36);
            tabPage5.Controls.Add(dataGridView4);
            tabPage5.Controls.Add(panel19);
            tabPage5.Controls.Add(panel18);
            tabPage5.Controls.Add(label17);
            tabPage5.Location = new Point(4, 29);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1034, 500);
            tabPage5.TabIndex = 4;
            tabPage5.Text = "Hoá đơn";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label36.ForeColor = Color.DodgerBlue;
            label36.Location = new Point(558, 231);
            label36.Name = "label36";
            label36.Size = new Size(167, 23);
            label36.TabIndex = 26;
            label36.Text = "Danh sách hoá đơn:";
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(565, 258);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersWidth = 51;
            dataGridView4.Size = new Size(463, 234);
            dataGridView4.TabIndex = 21;
            // 
            // panel19
            // 
            panel19.Controls.Add(listView1);
            panel19.Location = new Point(560, 60);
            panel19.Name = "panel19";
            panel19.Size = new Size(466, 171);
            panel19.TabIndex = 16;
            // 
            // listView1
            // 
            listView1.Location = new Point(2, 3);
            listView1.Name = "listView1";
            listView1.Size = new Size(463, 168);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            // 
            // panel18
            // 
            panel18.Controls.Add(groupBox7);
            panel18.Controls.Add(panel33);
            panel18.Controls.Add(panel30);
            panel18.Controls.Add(panel32);
            panel18.Controls.Add(panel31);
            panel18.Controls.Add(panel29);
            panel18.Controls.Add(panel28);
            panel18.Controls.Add(panel20);
            panel18.Location = new Point(9, 60);
            panel18.Name = "panel18";
            panel18.Size = new Size(547, 433);
            panel18.TabIndex = 15;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(btnXoa_Hoadon);
            groupBox7.Controls.Add(btnhoadon_find);
            groupBox7.Controls.Add(btnCapnhap_hoadon);
            groupBox7.Controls.Add(txtBHoaDon_find);
            groupBox7.Controls.Add(btnThem_Hoadon);
            groupBox7.Location = new Point(8, 305);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(526, 125);
            groupBox7.TabIndex = 20;
            groupBox7.TabStop = false;
            groupBox7.Text = "Chức năng";
            // 
            // btnXoa_Hoadon
            // 
            btnXoa_Hoadon.Location = new Point(367, 70);
            btnXoa_Hoadon.Name = "btnXoa_Hoadon";
            btnXoa_Hoadon.Size = new Size(127, 33);
            btnXoa_Hoadon.TabIndex = 2;
            btnXoa_Hoadon.Text = "Xoá";
            btnXoa_Hoadon.UseVisualStyleBackColor = true;
            // 
            // btnhoadon_find
            // 
            btnhoadon_find.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnhoadon_find.BackgroundImageLayout = ImageLayout.Stretch;
            btnhoadon_find.Location = new Point(209, 26);
            btnhoadon_find.Name = "btnhoadon_find";
            btnhoadon_find.Size = new Size(30, 30);
            btnhoadon_find.TabIndex = 3;
            btnhoadon_find.UseVisualStyleBackColor = true;
            // 
            // btnCapnhap_hoadon
            // 
            btnCapnhap_hoadon.Location = new Point(367, 26);
            btnCapnhap_hoadon.Name = "btnCapnhap_hoadon";
            btnCapnhap_hoadon.Size = new Size(127, 36);
            btnCapnhap_hoadon.TabIndex = 1;
            btnCapnhap_hoadon.Text = "Cập nhật";
            btnCapnhap_hoadon.UseVisualStyleBackColor = true;
            // 
            // txtBHoaDon_find
            // 
            txtBHoaDon_find.BorderStyle = BorderStyle.FixedSingle;
            txtBHoaDon_find.Location = new Point(12, 26);
            txtBHoaDon_find.Name = "txtBHoaDon_find";
            txtBHoaDon_find.PlaceholderText = "   Tìm kiếm";
            txtBHoaDon_find.Size = new Size(191, 27);
            txtBHoaDon_find.TabIndex = 2;
            // 
            // btnThem_Hoadon
            // 
            btnThem_Hoadon.Location = new Point(12, 66);
            btnThem_Hoadon.Name = "btnThem_Hoadon";
            btnThem_Hoadon.Size = new Size(127, 37);
            btnThem_Hoadon.TabIndex = 0;
            btnThem_Hoadon.Text = "Thêm";
            btnThem_Hoadon.UseVisualStyleBackColor = true;
            // 
            // panel33
            // 
            panel33.Controls.Add(numericUpDownHoadon_tinhtrang);
            panel33.Controls.Add(lblHoaDon_tinhtrang);
            panel33.Location = new Point(8, 218);
            panel33.Name = "panel33";
            panel33.Size = new Size(526, 34);
            panel33.TabIndex = 19;
            // 
            // numericUpDownHoadon_tinhtrang
            // 
            numericUpDownHoadon_tinhtrang.Location = new Point(119, 4);
            numericUpDownHoadon_tinhtrang.Maximum = new decimal(new int[] { 3, 0, 0, 0 });
            numericUpDownHoadon_tinhtrang.Name = "numericUpDownHoadon_tinhtrang";
            numericUpDownHoadon_tinhtrang.Size = new Size(80, 27);
            numericUpDownHoadon_tinhtrang.TabIndex = 1;
            // 
            // lblHoaDon_tinhtrang
            // 
            lblHoaDon_tinhtrang.AutoSize = true;
            lblHoaDon_tinhtrang.Location = new Point(8, 7);
            lblHoaDon_tinhtrang.Name = "lblHoaDon_tinhtrang";
            lblHoaDon_tinhtrang.Size = new Size(79, 20);
            lblHoaDon_tinhtrang.TabIndex = 0;
            lblHoaDon_tinhtrang.Text = "Tình trạng:";
            // 
            // panel30
            // 
            panel30.Controls.Add(txtBHoadon_somoi);
            panel30.Controls.Add(lblHoaDon_somoi);
            panel30.Location = new Point(276, 177);
            panel30.Name = "panel30";
            panel30.Size = new Size(258, 35);
            panel30.TabIndex = 7;
            // 
            // txtBHoadon_somoi
            // 
            txtBHoadon_somoi.Location = new Point(89, 4);
            txtBHoadon_somoi.Name = "txtBHoadon_somoi";
            txtBHoadon_somoi.Size = new Size(137, 27);
            txtBHoadon_somoi.TabIndex = 6;
            // 
            // lblHoaDon_somoi
            // 
            lblHoaDon_somoi.AutoSize = true;
            lblHoaDon_somoi.Location = new Point(8, 7);
            lblHoaDon_somoi.Name = "lblHoaDon_somoi";
            lblHoaDon_somoi.Size = new Size(59, 20);
            lblHoaDon_somoi.TabIndex = 6;
            lblHoaDon_somoi.Text = "Số mới:";
            // 
            // panel32
            // 
            panel32.Controls.Add(dateTimePickerHoaDon_date);
            panel32.Controls.Add(lblHoaDon_Ngay);
            panel32.Location = new Point(8, 137);
            panel32.Name = "panel32";
            panel32.Size = new Size(526, 34);
            panel32.TabIndex = 18;
            // 
            // dateTimePickerHoaDon_date
            // 
            dateTimePickerHoaDon_date.Location = new Point(106, 3);
            dateTimePickerHoaDon_date.Name = "dateTimePickerHoaDon_date";
            dateTimePickerHoaDon_date.Size = new Size(272, 27);
            dateTimePickerHoaDon_date.TabIndex = 1;
            dateTimePickerHoaDon_date.Value = new DateTime(2024, 11, 26, 0, 0, 0, 0);
            // 
            // lblHoaDon_Ngay
            // 
            lblHoaDon_Ngay.AutoSize = true;
            lblHoaDon_Ngay.Location = new Point(12, 6);
            lblHoaDon_Ngay.Name = "lblHoaDon_Ngay";
            lblHoaDon_Ngay.Size = new Size(47, 20);
            lblHoaDon_Ngay.TabIndex = 0;
            lblHoaDon_Ngay.Text = "Ngày:";
            // 
            // panel31
            // 
            panel31.Controls.Add(txBHoadon_id);
            panel31.Controls.Add(lblHoaDon_id);
            panel31.Location = new Point(8, 7);
            panel31.Name = "panel31";
            panel31.Size = new Size(526, 35);
            panel31.TabIndex = 8;
            // 
            // txBHoadon_id
            // 
            txBHoadon_id.Location = new Point(106, 3);
            txBHoadon_id.Name = "txBHoadon_id";
            txBHoadon_id.Size = new Size(137, 27);
            txBHoadon_id.TabIndex = 6;
            txBHoadon_id.TextChanged += textBox11_TextChanged;
            // 
            // lblHoaDon_id
            // 
            lblHoaDon_id.AutoSize = true;
            lblHoaDon_id.Location = new Point(8, 7);
            lblHoaDon_id.Name = "lblHoaDon_id";
            lblHoaDon_id.Size = new Size(92, 20);
            lblHoaDon_id.TabIndex = 6;
            lblHoaDon_id.Text = "Mã hoá đơn:";
            // 
            // panel29
            // 
            panel29.Controls.Add(lblHoaDon_tongtien);
            panel29.Controls.Add(txtBHoadon_tongtien);
            panel29.Location = new Point(8, 258);
            panel29.Name = "panel29";
            panel29.Size = new Size(526, 35);
            panel29.TabIndex = 7;
            // 
            // lblHoaDon_tongtien
            // 
            lblHoaDon_tongtien.AutoSize = true;
            lblHoaDon_tongtien.Location = new Point(5, 7);
            lblHoaDon_tongtien.Name = "lblHoaDon_tongtien";
            lblHoaDon_tongtien.Size = new Size(75, 20);
            lblHoaDon_tongtien.TabIndex = 5;
            lblHoaDon_tongtien.Text = "Tổng tiền:";
            // 
            // txtBHoadon_tongtien
            // 
            txtBHoadon_tongtien.Location = new Point(106, 3);
            txtBHoadon_tongtien.Name = "txtBHoadon_tongtien";
            txtBHoadon_tongtien.Size = new Size(206, 27);
            txtBHoadon_tongtien.TabIndex = 4;
            // 
            // panel28
            // 
            panel28.Controls.Add(txtBHoadon_socu);
            panel28.Controls.Add(lblHoaDon_socu);
            panel28.Location = new Point(8, 177);
            panel28.Name = "panel28";
            panel28.Size = new Size(261, 35);
            panel28.TabIndex = 6;
            // 
            // txtBHoadon_socu
            // 
            txtBHoadon_socu.Location = new Point(106, 5);
            txtBHoadon_socu.Name = "txtBHoadon_socu";
            txtBHoadon_socu.Size = new Size(134, 27);
            txtBHoadon_socu.TabIndex = 6;
            // 
            // lblHoaDon_socu
            // 
            lblHoaDon_socu.AutoSize = true;
            lblHoaDon_socu.Location = new Point(8, 7);
            lblHoaDon_socu.Name = "lblHoaDon_socu";
            lblHoaDon_socu.Size = new Size(48, 20);
            lblHoaDon_socu.TabIndex = 6;
            lblHoaDon_socu.Text = "Số cũ:";
            // 
            // panel20
            // 
            panel20.Controls.Add(btnChoose);
            panel20.Controls.Add(comboBoxServicesHoaDon_dv_id);
            panel20.Controls.Add(comboBoxRoomHoaDon_p_id);
            panel20.Location = new Point(8, 48);
            panel20.Name = "panel20";
            panel20.Size = new Size(526, 83);
            panel20.TabIndex = 17;
            // 
            // btnChoose
            // 
            btnChoose.Location = new Point(420, 10);
            btnChoose.Name = "btnChoose";
            btnChoose.Size = new Size(74, 62);
            btnChoose.TabIndex = 2;
            btnChoose.Text = "Chọn";
            btnChoose.UseVisualStyleBackColor = true;
            // 
            // comboBoxServicesHoaDon_dv_id
            // 
            comboBoxServicesHoaDon_dv_id.FormattingEnabled = true;
            comboBoxServicesHoaDon_dv_id.Location = new Point(8, 44);
            comboBoxServicesHoaDon_dv_id.Name = "comboBoxServicesHoaDon_dv_id";
            comboBoxServicesHoaDon_dv_id.Size = new Size(241, 28);
            comboBoxServicesHoaDon_dv_id.TabIndex = 1;
            comboBoxServicesHoaDon_dv_id.Text = "Dịch vụ";
            // 
            // comboBoxRoomHoaDon_p_id
            // 
            comboBoxRoomHoaDon_p_id.FormattingEnabled = true;
            comboBoxRoomHoaDon_p_id.Location = new Point(8, 10);
            comboBoxRoomHoaDon_p_id.Name = "comboBoxRoomHoaDon_p_id";
            comboBoxRoomHoaDon_p_id.Size = new Size(142, 28);
            comboBoxRoomHoaDon_p_id.TabIndex = 0;
            comboBoxRoomHoaDon_p_id.Text = "Phòng";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label17.ForeColor = Color.DodgerBlue;
            label17.Location = new Point(430, 13);
            label17.Name = "label17";
            label17.Size = new Size(218, 30);
            label17.TabIndex = 14;
            label17.Text = "QUẢN LÝ HOÁ ĐƠN";
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label18);
            tabPage1.Controls.Add(label19);
            tabPage1.Controls.Add(dataGridView5);
            tabPage1.Controls.Add(groupBox9);
            tabPage1.Controls.Add(groupBox10);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1034, 500);
            tabPage1.TabIndex = 5;
            tabPage1.Text = "Dịch vụ";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label18.ForeColor = Color.DodgerBlue;
            label18.Location = new Point(30, 278);
            label18.Name = "label18";
            label18.Size = new Size(159, 23);
            label18.TabIndex = 20;
            label18.Text = "Danh sách dịch vụ:";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label19.ForeColor = Color.DodgerBlue;
            label19.Location = new Point(411, 24);
            label19.Name = "label19";
            label19.Size = new Size(204, 30);
            label19.TabIndex = 19;
            label19.Text = "QUẢN LÝ DỊCH VỤ";
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(30, 304);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 51;
            dataGridView5.Size = new Size(974, 189);
            dataGridView5.TabIndex = 18;
            // 
            // groupBox9
            // 
            groupBox9.Controls.Add(txtBDv_find);
            groupBox9.Controls.Add(btnDv_find);
            groupBox9.Controls.Add(btnXoa_DV);
            groupBox9.Controls.Add(btnCapnhat_DV);
            groupBox9.Controls.Add(btnThem_DV);
            groupBox9.Location = new Point(760, 69);
            groupBox9.Name = "groupBox9";
            groupBox9.Size = new Size(244, 192);
            groupBox9.TabIndex = 17;
            groupBox9.TabStop = false;
            groupBox9.Text = "Chức năng";
            // 
            // txtBDv_find
            // 
            txtBDv_find.BorderStyle = BorderStyle.FixedSingle;
            txtBDv_find.Location = new Point(16, 29);
            txtBDv_find.Name = "txtBDv_find";
            txtBDv_find.PlaceholderText = "   Tìm kiếm";
            txtBDv_find.Size = new Size(191, 27);
            txtBDv_find.TabIndex = 2;
            // 
            // btnDv_find
            // 
            btnDv_find.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnDv_find.BackgroundImageLayout = ImageLayout.Stretch;
            btnDv_find.Location = new Point(208, 26);
            btnDv_find.Name = "btnDv_find";
            btnDv_find.Size = new Size(30, 30);
            btnDv_find.TabIndex = 3;
            btnDv_find.UseVisualStyleBackColor = true;
            // 
            // btnXoa_DV
            // 
            btnXoa_DV.Location = new Point(16, 153);
            btnXoa_DV.Name = "btnXoa_DV";
            btnXoa_DV.Size = new Size(127, 33);
            btnXoa_DV.TabIndex = 2;
            btnXoa_DV.Text = "Xoá";
            btnXoa_DV.UseVisualStyleBackColor = true;
            // 
            // btnCapnhat_DV
            // 
            btnCapnhat_DV.Location = new Point(16, 111);
            btnCapnhat_DV.Name = "btnCapnhat_DV";
            btnCapnhat_DV.Size = new Size(127, 36);
            btnCapnhat_DV.TabIndex = 1;
            btnCapnhat_DV.Text = "Cập nhật";
            btnCapnhat_DV.UseVisualStyleBackColor = true;
            // 
            // btnThem_DV
            // 
            btnThem_DV.Location = new Point(16, 68);
            btnThem_DV.Name = "btnThem_DV";
            btnThem_DV.Size = new Size(127, 37);
            btnThem_DV.TabIndex = 0;
            btnThem_DV.Text = "Thêm";
            btnThem_DV.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            groupBox10.Controls.Add(panel17);
            groupBox10.Controls.Add(panel21);
            groupBox10.Controls.Add(panel22);
            groupBox10.Location = new Point(30, 69);
            groupBox10.Name = "groupBox10";
            groupBox10.Size = new Size(724, 192);
            groupBox10.TabIndex = 16;
            groupBox10.TabStop = false;
            groupBox10.Text = "Thông tin dịch vụ:";
            // 
            // panel17
            // 
            panel17.Controls.Add(txtBDV_price);
            panel17.Controls.Add(lnlDV_price);
            panel17.Location = new Point(381, 36);
            panel17.Name = "panel17";
            panel17.Size = new Size(262, 34);
            panel17.TabIndex = 3;
            // 
            // txtBDV_price
            // 
            txtBDV_price.BorderStyle = BorderStyle.FixedSingle;
            txtBDV_price.Location = new Point(97, 3);
            txtBDV_price.Name = "txtBDV_price";
            txtBDV_price.Size = new Size(120, 27);
            txtBDV_price.TabIndex = 3;
            // 
            // lnlDV_price
            // 
            lnlDV_price.AutoSize = true;
            lnlDV_price.Location = new Point(12, 6);
            lnlDV_price.Name = "lnlDV_price";
            lnlDV_price.Size = new Size(65, 20);
            lnlDV_price.TabIndex = 0;
            lnlDV_price.Text = "Đơn giá:";
            // 
            // panel21
            // 
            panel21.Controls.Add(txtBDV_name);
            panel21.Controls.Add(lblDV_name);
            panel21.Location = new Point(15, 94);
            panel21.Name = "panel21";
            panel21.Size = new Size(327, 34);
            panel21.TabIndex = 2;
            // 
            // txtBDV_name
            // 
            txtBDV_name.BorderStyle = BorderStyle.FixedSingle;
            txtBDV_name.Location = new Point(104, 3);
            txtBDV_name.Name = "txtBDV_name";
            txtBDV_name.Size = new Size(220, 27);
            txtBDV_name.TabIndex = 2;
            // 
            // lblDV_name
            // 
            lblDV_name.AutoSize = true;
            lblDV_name.Location = new Point(12, 6);
            lblDV_name.Name = "lblDV_name";
            lblDV_name.Size = new Size(86, 20);
            lblDV_name.TabIndex = 0;
            lblDV_name.Text = "Tên dịch vụ:";
            // 
            // panel22
            // 
            panel22.Controls.Add(txtBDV_id);
            panel22.Controls.Add(lblDichvu_id);
            panel22.Location = new Point(15, 30);
            panel22.Name = "panel22";
            panel22.Size = new Size(327, 34);
            panel22.TabIndex = 0;
            // 
            // txtBDV_id
            // 
            txtBDV_id.BorderStyle = BorderStyle.FixedSingle;
            txtBDV_id.Location = new Point(104, 3);
            txtBDV_id.Name = "txtBDV_id";
            txtBDV_id.Size = new Size(129, 27);
            txtBDV_id.TabIndex = 1;
            // 
            // lblDichvu_id
            // 
            lblDichvu_id.AutoSize = true;
            lblDichvu_id.Location = new Point(12, 6);
            lblDichvu_id.Name = "lblDichvu_id";
            lblDichvu_id.Size = new Size(84, 20);
            lblDichvu_id.TabIndex = 0;
            lblDichvu_id.Text = "Mã dịch vụ:";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(dataGridView6);
            tabPage2.Controls.Add(label26);
            tabPage2.Controls.Add(label27);
            tabPage2.Controls.Add(groupBox11);
            tabPage2.Controls.Add(groupBox12);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1034, 500);
            tabPage2.TabIndex = 6;
            tabPage2.Text = "Biển số xe";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            dataGridView6.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView6.Location = new Point(24, 304);
            dataGridView6.Name = "dataGridView6";
            dataGridView6.RowHeadersWidth = 51;
            dataGridView6.Size = new Size(980, 193);
            dataGridView6.TabIndex = 26;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label26.ForeColor = Color.DodgerBlue;
            label26.Location = new Point(18, 278);
            label26.Name = "label26";
            label26.Size = new Size(181, 23);
            label26.TabIndex = 25;
            label26.Text = "Danh sách biển số xe:";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label27.ForeColor = Color.DodgerBlue;
            label27.Location = new Point(411, 24);
            label27.Name = "label27";
            label27.Size = new Size(230, 30);
            label27.TabIndex = 24;
            label27.Text = "QUẢN LÝ BIỂN SỐ XE";
            // 
            // groupBox11
            // 
            groupBox11.Controls.Add(txtBfind_BSX);
            groupBox11.Controls.Add(btnfind_BSX);
            groupBox11.Controls.Add(btnXoa_BSX);
            groupBox11.Controls.Add(btnCapNhat_BSX);
            groupBox11.Controls.Add(btnThem_BSX);
            groupBox11.Location = new Point(760, 69);
            groupBox11.Name = "groupBox11";
            groupBox11.Size = new Size(244, 192);
            groupBox11.TabIndex = 22;
            groupBox11.TabStop = false;
            groupBox11.Text = "Chức năng";
            // 
            // txtBfind_BSX
            // 
            txtBfind_BSX.BorderStyle = BorderStyle.FixedSingle;
            txtBfind_BSX.Location = new Point(16, 29);
            txtBfind_BSX.Name = "txtBfind_BSX";
            txtBfind_BSX.PlaceholderText = "   Tìm kiếm";
            txtBfind_BSX.Size = new Size(191, 27);
            txtBfind_BSX.TabIndex = 2;
            // 
            // btnfind_BSX
            // 
            btnfind_BSX.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnfind_BSX.BackgroundImageLayout = ImageLayout.Stretch;
            btnfind_BSX.Location = new Point(208, 26);
            btnfind_BSX.Name = "btnfind_BSX";
            btnfind_BSX.Size = new Size(30, 30);
            btnfind_BSX.TabIndex = 3;
            btnfind_BSX.UseVisualStyleBackColor = true;
            // 
            // btnXoa_BSX
            // 
            btnXoa_BSX.Location = new Point(16, 153);
            btnXoa_BSX.Name = "btnXoa_BSX";
            btnXoa_BSX.Size = new Size(127, 33);
            btnXoa_BSX.TabIndex = 2;
            btnXoa_BSX.Text = "Xoá";
            btnXoa_BSX.UseVisualStyleBackColor = true;
            // 
            // btnCapNhat_BSX
            // 
            btnCapNhat_BSX.Location = new Point(16, 111);
            btnCapNhat_BSX.Name = "btnCapNhat_BSX";
            btnCapNhat_BSX.Size = new Size(127, 36);
            btnCapNhat_BSX.TabIndex = 1;
            btnCapNhat_BSX.Text = "Cập nhật";
            btnCapNhat_BSX.UseVisualStyleBackColor = true;
            // 
            // btnThem_BSX
            // 
            btnThem_BSX.Location = new Point(16, 68);
            btnThem_BSX.Name = "btnThem_BSX";
            btnThem_BSX.Size = new Size(127, 37);
            btnThem_BSX.TabIndex = 0;
            btnThem_BSX.Text = "Thêm";
            btnThem_BSX.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            groupBox12.Controls.Add(panel24);
            groupBox12.Controls.Add(panel25);
            groupBox12.Location = new Point(24, 69);
            groupBox12.Name = "groupBox12";
            groupBox12.Size = new Size(730, 192);
            groupBox12.TabIndex = 21;
            groupBox12.TabStop = false;
            groupBox12.Text = "Thông tin biển số xe:";
            // 
            // panel24
            // 
            panel24.Controls.Add(txtBBSX_id);
            panel24.Controls.Add(lblBSX_id);
            panel24.Location = new Point(15, 94);
            panel24.Name = "panel24";
            panel24.Size = new Size(327, 34);
            panel24.TabIndex = 2;
            // 
            // txtBBSX_id
            // 
            txtBBSX_id.BorderStyle = BorderStyle.FixedSingle;
            txtBBSX_id.Location = new Point(104, 3);
            txtBBSX_id.Name = "txtBBSX_id";
            txtBBSX_id.Size = new Size(122, 27);
            txtBBSX_id.TabIndex = 2;
            // 
            // lblBSX_id
            // 
            lblBSX_id.AutoSize = true;
            lblBSX_id.Location = new Point(12, 6);
            lblBSX_id.Name = "lblBSX_id";
            lblBSX_id.Size = new Size(79, 20);
            lblBSX_id.TabIndex = 0;
            lblBSX_id.Text = "Biển số xe:";
            // 
            // panel25
            // 
            panel25.Controls.Add(txtBBSX_cccd_kt);
            panel25.Controls.Add(lblBSX_cccd_kt);
            panel25.Location = new Point(15, 30);
            panel25.Name = "panel25";
            panel25.Size = new Size(327, 34);
            panel25.TabIndex = 0;
            // 
            // txtBBSX_cccd_kt
            // 
            txtBBSX_cccd_kt.BorderStyle = BorderStyle.FixedSingle;
            txtBBSX_cccd_kt.Location = new Point(104, 3);
            txtBBSX_cccd_kt.Name = "txtBBSX_cccd_kt";
            txtBBSX_cccd_kt.Size = new Size(220, 27);
            txtBBSX_cccd_kt.TabIndex = 1;
            // 
            // lblBSX_cccd_kt
            // 
            lblBSX_cccd_kt.AutoSize = true;
            lblBSX_cccd_kt.Location = new Point(12, 6);
            lblBSX_cccd_kt.Name = "lblBSX_cccd_kt";
            lblBSX_cccd_kt.Size = new Size(71, 20);
            lblBSX_cccd_kt.TabIndex = 0;
            lblBSX_cccd_kt.Text = "Số CCCD:";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(label28);
            tabPage3.Controls.Add(label31);
            tabPage3.Controls.Add(dataGridView7);
            tabPage3.Controls.Add(groupBox13);
            tabPage3.Controls.Add(groupBox14);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(1034, 500);
            tabPage3.TabIndex = 7;
            tabPage3.Text = "Tài khoản khách thuê";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label28.ForeColor = Color.DodgerBlue;
            label28.Location = new Point(30, 278);
            label28.Name = "label28";
            label28.Size = new Size(269, 23);
            label28.TabIndex = 30;
            label28.Text = "Danh sách tài khoản khách thuê:";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label31.ForeColor = Color.DodgerBlue;
            label31.Location = new Point(353, 20);
            label31.Name = "label31";
            label31.Size = new Size(380, 30);
            label31.TabIndex = 29;
            label31.Text = "QUẢN LÝ TÀI KHOẢN KHÁCH THUÊ";
            // 
            // dataGridView7
            // 
            dataGridView7.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView7.Location = new Point(30, 304);
            dataGridView7.Name = "dataGridView7";
            dataGridView7.RowHeadersWidth = 51;
            dataGridView7.Size = new Size(974, 173);
            dataGridView7.TabIndex = 28;
            // 
            // groupBox13
            // 
            groupBox13.Controls.Add(txtBfind_TKKT);
            groupBox13.Controls.Add(btnfind_tkkt);
            groupBox13.Controls.Add(btnXoa_tkkt);
            groupBox13.Controls.Add(btnCapnhat_tkkt);
            groupBox13.Controls.Add(btnThem_tkkkt);
            groupBox13.Location = new Point(760, 69);
            groupBox13.Name = "groupBox13";
            groupBox13.Size = new Size(244, 192);
            groupBox13.TabIndex = 27;
            groupBox13.TabStop = false;
            groupBox13.Text = "Chức năng";
            // 
            // txtBfind_TKKT
            // 
            txtBfind_TKKT.BorderStyle = BorderStyle.FixedSingle;
            txtBfind_TKKT.Location = new Point(16, 29);
            txtBfind_TKKT.Name = "txtBfind_TKKT";
            txtBfind_TKKT.PlaceholderText = "   Tìm kiếm";
            txtBfind_TKKT.Size = new Size(191, 27);
            txtBfind_TKKT.TabIndex = 2;
            // 
            // btnfind_tkkt
            // 
            btnfind_tkkt.BackgroundImage = Properties.Resources.searchmagnifierinterfacesymbol_79894;
            btnfind_tkkt.BackgroundImageLayout = ImageLayout.Stretch;
            btnfind_tkkt.Location = new Point(208, 26);
            btnfind_tkkt.Name = "btnfind_tkkt";
            btnfind_tkkt.Size = new Size(30, 30);
            btnfind_tkkt.TabIndex = 3;
            btnfind_tkkt.UseVisualStyleBackColor = true;
            // 
            // btnXoa_tkkt
            // 
            btnXoa_tkkt.Location = new Point(16, 153);
            btnXoa_tkkt.Name = "btnXoa_tkkt";
            btnXoa_tkkt.Size = new Size(127, 33);
            btnXoa_tkkt.TabIndex = 2;
            btnXoa_tkkt.Text = "Xoá";
            btnXoa_tkkt.UseVisualStyleBackColor = true;
            // 
            // btnCapnhat_tkkt
            // 
            btnCapnhat_tkkt.Location = new Point(16, 111);
            btnCapnhat_tkkt.Name = "btnCapnhat_tkkt";
            btnCapnhat_tkkt.Size = new Size(127, 36);
            btnCapnhat_tkkt.TabIndex = 1;
            btnCapnhat_tkkt.Text = "Cập nhật";
            btnCapnhat_tkkt.UseVisualStyleBackColor = true;
            // 
            // btnThem_tkkkt
            // 
            btnThem_tkkkt.Location = new Point(16, 68);
            btnThem_tkkkt.Name = "btnThem_tkkkt";
            btnThem_tkkkt.Size = new Size(127, 37);
            btnThem_tkkkt.TabIndex = 0;
            btnThem_tkkkt.Text = "Thêm";
            btnThem_tkkkt.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            groupBox14.Controls.Add(panel27);
            groupBox14.Controls.Add(panel23);
            groupBox14.Controls.Add(panel26);
            groupBox14.Location = new Point(30, 69);
            groupBox14.Name = "groupBox14";
            groupBox14.Size = new Size(724, 192);
            groupBox14.TabIndex = 26;
            groupBox14.TabStop = false;
            groupBox14.Text = "Thông tin tài khoản khách thuê:";
            // 
            // panel27
            // 
            panel27.Controls.Add(txtBTKKT_Matkhau);
            panel27.Controls.Add(lblTKKT_Matkhau);
            panel27.Location = new Point(15, 152);
            panel27.Name = "panel27";
            panel27.Size = new Size(327, 34);
            panel27.TabIndex = 3;
            // 
            // txtBTKKT_Matkhau
            // 
            txtBTKKT_Matkhau.BorderStyle = BorderStyle.FixedSingle;
            txtBTKKT_Matkhau.Location = new Point(128, 3);
            txtBTKKT_Matkhau.Name = "txtBTKKT_Matkhau";
            txtBTKKT_Matkhau.Size = new Size(196, 27);
            txtBTKKT_Matkhau.TabIndex = 2;
            // 
            // lblTKKT_Matkhau
            // 
            lblTKKT_Matkhau.AutoSize = true;
            lblTKKT_Matkhau.Location = new Point(12, 6);
            lblTKKT_Matkhau.Name = "lblTKKT_Matkhau";
            lblTKKT_Matkhau.Size = new Size(73, 20);
            lblTKKT_Matkhau.TabIndex = 0;
            lblTKKT_Matkhau.Text = "Mật khẩu:";
            // 
            // panel23
            // 
            panel23.Controls.Add(txtBTKKKT_tenDN);
            panel23.Controls.Add(lblTKKT_tenDN);
            panel23.Location = new Point(15, 94);
            panel23.Name = "panel23";
            panel23.Size = new Size(327, 34);
            panel23.TabIndex = 2;
            // 
            // txtBTKKKT_tenDN
            // 
            txtBTKKKT_tenDN.BorderStyle = BorderStyle.FixedSingle;
            txtBTKKKT_tenDN.Location = new Point(128, 3);
            txtBTKKKT_tenDN.Name = "txtBTKKKT_tenDN";
            txtBTKKKT_tenDN.Size = new Size(196, 27);
            txtBTKKKT_tenDN.TabIndex = 2;
            // 
            // lblTKKT_tenDN
            // 
            lblTKKT_tenDN.AutoSize = true;
            lblTKKT_tenDN.Location = new Point(12, 6);
            lblTKKT_tenDN.Name = "lblTKKT_tenDN";
            lblTKKT_tenDN.Size = new Size(110, 20);
            lblTKKT_tenDN.TabIndex = 0;
            lblTKKT_tenDN.Text = "Tên đăng nhập:";
            // 
            // panel26
            // 
            panel26.Controls.Add(txtBTKKT_cccd);
            panel26.Controls.Add(lblTKKT_cccd);
            panel26.Location = new Point(15, 30);
            panel26.Name = "panel26";
            panel26.Size = new Size(332, 34);
            panel26.TabIndex = 0;
            // 
            // txtBTKKT_cccd
            // 
            txtBTKKT_cccd.BorderStyle = BorderStyle.FixedSingle;
            txtBTKKT_cccd.Location = new Point(128, 3);
            txtBTKKT_cccd.Name = "txtBTKKT_cccd";
            txtBTKKT_cccd.Size = new Size(196, 27);
            txtBTKKT_cccd.TabIndex = 1;
            // 
            // lblTKKT_cccd
            // 
            lblTKKT_cccd.AutoSize = true;
            lblTKKT_cccd.Location = new Point(12, 6);
            lblTKKT_cccd.Name = "lblTKKT_cccd";
            lblTKKT_cccd.Size = new Size(71, 20);
            lblTKKT_cccd.TabIndex = 0;
            lblTKKT_cccd.Text = "Số CCCD:";
            // 
            // fAdmincs
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources._2776a46468188ac77c3f1f473c3fb311;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1041, 535);
            Controls.Add(tabControl1);
            DoubleBuffered = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "fAdmincs";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Chức năng";
            tabControl1.ResumeLayout(false);
            tabPRoom.ResumeLayout(false);
            tabPRoom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)datagridviewPhong).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numUDP_tinhtrang).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numUDP_SL).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tabPCustomer.ResumeLayout(false);
            tabPCustomer.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            groupBox4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            tabPHopDong.ResumeLayout(false);
            tabPHopDong.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numUDHD_tinhtrang).EndInit();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            panel19.ResumeLayout(false);
            panel18.ResumeLayout(false);
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            panel33.ResumeLayout(false);
            panel33.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDownHoadon_tinhtrang).EndInit();
            panel30.ResumeLayout(false);
            panel30.PerformLayout();
            panel32.ResumeLayout(false);
            panel32.PerformLayout();
            panel31.ResumeLayout(false);
            panel31.PerformLayout();
            panel29.ResumeLayout(false);
            panel29.PerformLayout();
            panel28.ResumeLayout(false);
            panel28.PerformLayout();
            panel20.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            groupBox9.ResumeLayout(false);
            groupBox9.PerformLayout();
            groupBox10.ResumeLayout(false);
            panel17.ResumeLayout(false);
            panel17.PerformLayout();
            panel21.ResumeLayout(false);
            panel21.PerformLayout();
            panel22.ResumeLayout(false);
            panel22.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).EndInit();
            groupBox11.ResumeLayout(false);
            groupBox11.PerformLayout();
            groupBox12.ResumeLayout(false);
            panel24.ResumeLayout(false);
            panel24.PerformLayout();
            panel25.ResumeLayout(false);
            panel25.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView7).EndInit();
            groupBox13.ResumeLayout(false);
            groupBox13.PerformLayout();
            groupBox14.ResumeLayout(false);
            panel27.ResumeLayout(false);
            panel27.PerformLayout();
            panel23.ResumeLayout(false);
            panel23.PerformLayout();
            panel26.ResumeLayout(false);
            panel26.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPRoom;
        private TabPage tabPCustomer;
        private TabPage tabPHopDong;
        private TabPage tabPage5;
        private Label titleDSP;
        private Label titleQLPT;
        private DataGridView datagridviewPhong;
        private GroupBox groupBox1;
        private Label label4;
        private Panel panel4;
        private NumericUpDown numUDP_tinhtrang;
        private Label lblP_tinhtrang;
        private Panel panel3;
        private TextBox txtBPprice;
        private Label lblP_price;
        private Panel panel2;
        private NumericUpDown numUDP_SL;
        private Label lblP_quantity;
        private Panel panel1;
        private TextBox txtBP_ID;
        private Label lblP_ID;
        private Label label5;
        private DataGridView dataGridView2;
        private GroupBox groupBox4;
        private Panel panel5;
        private TextBox txtBKTphone;
        private Label lblKT_phone;
        private Panel panel6;
        private RadioButton rBtnKT_sex_0;
        private RadioButton rBtnKT_sex_1;
        private Label lblKT_sex;
        private Panel panel7;
        private RichTextBox rtxtBKTaddress;
        private Label lblKT_address;
        private Panel panel8;
        private TextBox txtKT_name;
        private Label lblKT_name;
        private Panel panel9;
        private TextBox txtBKTname;
        private Label lblKT_CCCD;
        private Label titleQLKT;
        private GroupBox groupBox2;
        private TextBox txtBfind_P;
        private Button btnSearch_P;
        private Button btnXoa_P;
        private Button btnCapNhat_P;
        private Button btnThem_P;
        private GroupBox groupBox3;
        private TextBox txtFind_KT;
        private Button btnFind_KT;
        private Button btnXoa_KT;
        private Button btnCapNhat_KT;
        private Button btnThem_KT;
        private Label label6;
        private GroupBox groupBox5;
        private Label label7;
        private Panel panel10;
        private TextBox txtBHD_p_id;
        private Label lblHD_p_id;
        private Panel panel11;
        private TextBox txtBHD_cccd_ct;
        private Label lblHD_cccd_ct;
        private Panel panel12;
        private TextBox txtBHD_cccd_kt;
        private Label lblHD_cccd_kt;
        private Panel panel13;
        private DateTimePicker dateTimePickerHD_dayend;
        private Label lblHD_dayend;
        private Panel panel14;
        private NumericUpDown numUDHD_tinhtrang;
        private Label lblHD_tinhtrang;
        private Panel panel15;
        private DateTimePicker dateTimePickerHD_daystart;
        private Label lblHD_daystart;
        private Panel panel16;
        private TextBox txtBHD_ID;
        private Label lnlHD_ID;
        private DataGridView dataGridView3;
        private Label label15;
        private GroupBox groupBox6;
        private TextBox txtBHD_find;
        private Button btnFind_HD;
        private Button btnCapnhat_HD;
        private Button btnThem_HD;
        private Label label17;
        private TabPage tabPage1;
        private Label label18;
        private Label label19;
        private DataGridView dataGridView5;
        private GroupBox groupBox9;
        private TextBox txtBDv_find;
        private Button btnDv_find;
        private Button btnXoa_DV;
        private Button btnCapnhat_DV;
        private Button btnThem_DV;
        private GroupBox groupBox10;
        private Panel panel17;
        private TextBox txtBDV_price;
        private Label lnlDV_price;
        private Panel panel21;
        private TextBox txtBDV_name;
        private Label lblDV_name;
        private Panel panel22;
        private TextBox txtBDV_id;
        private Label lblDichvu_id;
        private TabPage tabPage2;
        private Label label26;
        private Label label27;
        private GroupBox groupBox11;
        private TextBox txtBfind_BSX;
        private Button btnfind_BSX;
        private Button btnXoa_BSX;
        private Button btnCapNhat_BSX;
        private Button btnThem_BSX;
        private GroupBox groupBox12;
        private Panel panel24;
        private TextBox txtBBSX_id;
        private Label lblBSX_id;
        private Panel panel25;
        private TextBox txtBBSX_cccd_kt;
        private Label lblBSX_cccd_kt;
        private TabPage tabPage3;
        private Label label28;
        private Label label31;
        private DataGridView dataGridView7;
        private GroupBox groupBox13;
        private TextBox txtBfind_TKKT;
        private Button btnfind_tkkt;
        private Button btnXoa_tkkt;
        private Button btnCapnhat_tkkt;
        private Button btnThem_tkkkt;
        private GroupBox groupBox14;
        private Panel panel27;
        private TextBox txtBTKKT_Matkhau;
        private Label lblTKKT_Matkhau;
        private Panel panel23;
        private TextBox txtBTKKKT_tenDN;
        private Label lblTKKT_tenDN;
        private Panel panel26;
        private TextBox txtBTKKT_cccd;
        private Label lblTKKT_cccd;
        private Panel panel18;
        private Panel panel20;
        private ComboBox comboBoxRoomHoaDon_p_id;
        private Panel panel19;
        private ListView listView1;
        private Button btnChoose;
        private ComboBox comboBoxServicesHoaDon_dv_id;
        private Label lblHoaDon_tongtien;
        private TextBox txtBHoadon_tongtien;
        private Panel panel28;
        private Panel panel30;
        private TextBox txtBHoadon_somoi;
        private Label lblHoaDon_somoi;
        private Panel panel31;
        private TextBox txBHoadon_id;
        private Label lblHoaDon_id;
        private Panel panel29;
        private TextBox txtBHoadon_socu;
        private Label lblHoaDon_socu;
        private Panel panel32;
        private DateTimePicker dateTimePickerHoaDon_date;
        private Label lblHoaDon_Ngay;
        private GroupBox groupBox7;
        private Button btnXoa_Hoadon;
        private Button btnhoadon_find;
        private Button btnCapnhap_hoadon;
        private TextBox txtBHoaDon_find;
        private Button btnThem_Hoadon;
        private Panel panel33;
        private NumericUpDown numericUpDownHoadon_tinhtrang;
        private Label lblHoaDon_tinhtrang;
        private Label label36;
        private DataGridView dataGridView4;
        private DataGridView dataGridView6;
    }
}